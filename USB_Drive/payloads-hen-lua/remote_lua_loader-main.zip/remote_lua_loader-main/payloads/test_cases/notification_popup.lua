function main()
    send_ps_notification("Hello world")
end

main()
